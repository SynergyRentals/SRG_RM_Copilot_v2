# Synergy RM Copilot v2

This repository bootstraps the **Synergy RM Copilot** – an autonomous
development loop that leverages OpenAI agents to tackle tasks filed as
GitHub issues. When an issue is created and labeled `ai‑task`, a
GitHub Action triggers the agent defined in `agent.yaml`. The agent
reads the issue body, makes changes in the repository using the
filesystem tool, runs tests, and opens a pull request with its
modifications. This workflow enables rapid, automated iteration
without manual intervention.

## Project structure

| Path | Purpose |
| --- | --- |
| `pyproject.toml` | Declares the Python package metadata and pins runtime and development dependencies (OpenAI, agents SDK, httpx, pydantic, pyyaml, pandas, ruff, pytest) |
| `src/srg_rm_copilot/__init__.py` | Empty package module for future code additions |
| `.github/scripts/run_agent.py` | Entry point invoked by the GitHub Actions workflow. It loads the issue body from the event payload and executes the agent defined in `agent.yaml` |
| `agent.yaml` | YAML configuration describing the agent (model, tools, instructions, branch prefix, test command) |
| `.github/workflows/ai_task.yml` | GitHub Actions workflow that triggers on issues labeled `ai‑task` and runs the agent |

## Required secrets

To enable the agent and workflows you must configure the following
repository secrets (in **GitHub → Settings → Secrets and variables →
Actions**). **Do not commit any secret values into the repository.**

| Secret | Purpose |
| --- | --- |
| `OPENAI_API_KEY` | API key for the OpenAI account used by the agent. Required for model invocations |
| `WHEELHOUSE_API_KEY` | Read‑only API key for Wheelhouse. The agent must not have write permission to Wheelhouse |
| `WHEELHOUSE_USER_API_KEY` | User‑level API key for Wheelhouse in read‑only mode |
| `GIT_TOKEN` | Personal access token with permissions to create branches and pull requests. The agent uses this token when making PRs |

After adding these secrets, they will be automatically injected as
environment variables into the `ai_task` workflow.

## Testing the agent loop

1. Ensure the repository exists and that you have created a branch named
   `v2` from `main` (or start with a fresh repo if it does not exist).
2. Commit the files from this repository into the `v2` branch and push
   to GitHub.
3. Add the secrets listed above under **Settings → Secrets and
   variables → Actions**.
4. (Optional) Configure a deployment on [Replit](https://replit.com/) so that
   merges into `main` or `v2` automatically deploy. A simple approach is
   to create a new Repl from GitHub and enable auto‑deploy on push. If
   you already have a Replit webhook configured for the original project,
   update it to point at this repository or branch. If you cannot
   configure the webhook automatically, leave a TODO in your internal
   tracking system and set it up manually.
5. To test the loop, open a new GitHub issue in this repository with a
   descriptive title. In the issue body describe a small coding task,
   such as adding a function or writing a unit test. **Label the issue
   `ai‑task`**. Once the issue is created and labeled, the GitHub Action
   will run the agent. If everything is configured correctly you should
   see a new branch and pull request created by the agent with the
   branch name starting with `auto/ai‑task-` and containing the changes
   requested in the issue.

## Limitations and TODOs

* This repository only scaffolds the agent and workflow. The initial
  implementation of `run_agent.py` gracefully degrades if the
  `openai‑agents‑python` SDK is not available in the execution
  environment. It will log a warning instead of failing hard. To use
  the full capabilities of the agent you must ensure that the SDK is
  installable in your GitHub Actions runners.
* The workflow currently installs dependencies directly via `pip`.
  Depending on your organisation’s network policies you may need to
  configure a proxy or mirror.
* Replit deployment is not configured automatically. You will need to
  either reuse an existing webhook or manually create one that triggers
  on pushes to `main` and `v2`.