#!/usr/bin/env python3
"""
GitHub Action entry point for the Synergy RM Copilot agent.

This script is invoked by the GitHub Actions workflow defined in
`.github/workflows/ai_task.yml`. It reads the incoming issue event from
`GITHUB_EVENT_PATH`, extracts the issue body, and passes it to the agent
defined in `agent.yaml`. The agent is expected to read the issue body,
perform the requested work (generating code, running tests, opening a PR,
etc.), and exit.

The `openai-agents-python` SDK must be installed in the GitHub Actions
environment for this script to function. If the SDK is not available the
script logs an error and returns.

Secrets (e.g. `OPENAI_API_KEY`, `WHEELHOUSE_API_KEY`, `WHEELHOUSE_USER_API_KEY`,
and `GIT_TOKEN`) must be configured as repository secrets and exposed to
the workflow via `env:` in the workflow file.
"""

import json
import logging
import os
import sys


def load_issue_body(event_path: str) -> str:
    """Load the issue body from the GitHub event JSON file.

    The GitHub Actions runtime writes the event payload to the path
    specified by the `GITHUB_EVENT_PATH` environment variable. This helper
    reads the JSON, extracts the `issue` object (or `pull_request` as a
    fallback) and returns the `body` field. If no body is available
    an empty string is returned.

    Args:
        event_path: Path to the GitHub event JSON file.

    Returns:
        The text body of the issue.
    """
    try:
        with open(event_path, "r", encoding="utf-8") as f:
            event = json.load(f)
        issue = event.get("issue") or event.get("pull_request", {})
        return issue.get("body", "") or ""
    except Exception as exc:
        logging.exception("Failed to parse event payload: %s", exc)
        return ""


def run_agent(issue_body: str) -> None:
    """Instantiate and run the agent defined in `agent.yaml`.

    This function attempts to import the `openai-agents-python` SDK and
    create an agent using the YAML configuration in the repository root.
    It then passes the issue body to the agent's `run` method. Any
    unexpected exceptions will be logged and re-raised, causing the
    workflow step to fail.

    Args:
        issue_body: The plain text body of the GitHub issue triggering
            the workflow.
    """
    try:
        # Lazy import to allow unit tests to run without the SDK
        from openai_agents import Agent  # type: ignore
    except ImportError:
        logging.error(
            "openai-agents-python is not installed. Please ensure the dependency is "
            "declared in pyproject.toml and installed in your GitHub Actions workflow."
        )
        return

    try:
        agent = Agent.from_yaml("agent.yaml")
    except Exception as exc:
        logging.exception("Failed to load agent from YAML: %s", exc)
        raise

    try:
        # The agent API may support passing inputs via the `run` method. If
        # your version of the SDK differs, adjust accordingly.
        agent.run(issue_body)
    except Exception as exc:
        logging.exception("Agent execution failed: %s", exc)
        raise


def main() -> None:
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    event_path = os.environ.get("GITHUB_EVENT_PATH")
    if not event_path:
        logging.warning(
            "GITHUB_EVENT_PATH is not set. Skipping agent execution as no event payload is available."
        )
        return
    body = load_issue_body(event_path)
    if not body:
        logging.info("No issue body found in event payload. Nothing to process.")
        return
    run_agent(body)


if __name__ == "__main__":
    main()