# SPDX-License-Identifier: MIT
"""
Synergy RM Copilot package.

This package houses the core code for the autonomous development loop used
to build and maintain the Synergy RM Copilot system. The initial commit
contains only skeletal files and configuration necessary to bootstrap the
project. Subsequent automated PRs created via the `ai-task` workflow will
populate this package with additional modules.

Note: do not add any secrets or credentials in this package. All secret
values must be stored in GitHub repository secrets or other secure
mechanisms referenced in the README.
"""

__all__ = []